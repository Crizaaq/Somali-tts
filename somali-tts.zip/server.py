
import edge_tts, asyncio, nest_asyncio, io, os
from flask import Flask, request, send_file
from flask_cors import CORS

nest_asyncio.apply()
app = Flask(__name__)
CORS(app)

@app.route("/tts", methods=["POST"])
def tts():
    data  = request.json
    text  = data.get("text", "")
    voice = data.get("voice", "so-SO-MuuseNeural")
    rate  = data.get("rate",  "+0%")
    pitch = data.get("pitch", "+0Hz")

    async def generate():
        com = edge_tts.Communicate(text, voice, rate=rate, pitch=pitch)
        audio = b""
        async for chunk in com.stream():
            if chunk["type"] == "audio":
                audio += chunk["data"]
        return audio

    audio = asyncio.run(generate())
    return send_file(io.BytesIO(audio), mimetype="audio/mpeg")

@app.route("/health", methods=["GET"])
def health():
    return {"status": "ok"}

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port)
