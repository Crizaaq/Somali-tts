
import edge_tts
import asyncio
import nest_asyncio
from http.server import BaseHTTPRequestHandler
import json

nest_asyncio.apply()

class handler(BaseHTTPRequestHandler):

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self):
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(b'{"status":"ok","voices":["so-SO-MuuseNeural","so-SO-UbaxNeural"]}')

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        body   = json.loads(self.rfile.read(length))

        text  = body.get("text", "")
        voice = body.get("voice", "so-SO-MuuseNeural")
        rate  = body.get("rate",  "+0%")
        pitch = body.get("pitch", "+0Hz")

        async def generate():
            communicate = edge_tts.Communicate(text, voice, rate=rate, pitch=pitch)
            audio = b""
            async for chunk in communicate.stream():
                if chunk["type"] == "audio":
                    audio += chunk["data"]
            return audio

        audio = asyncio.run(generate())

        self.send_response(200)
        self.send_header("Content-Type", "audio/mpeg")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(audio)
